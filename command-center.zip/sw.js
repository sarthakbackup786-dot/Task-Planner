/* =========================================================================
   sw.js — minimal cache-first service worker so the app shell (HTML/CSS/JS
   + icons) works offline once visited. Data itself lives in localStorage,
   which persists regardless of the network — this cache is purely so the
   app can load with no connection at all.
   Bump CACHE_NAME whenever the shell files change, so old caches don't
   serve stale code.
   ========================================================================= */
const CACHE_NAME = "command-center-v1";
const SHELL_FILES = [
  "./",
  "./index.html",
  "./styles.css",
  "./manifest.json",
  "./js/state.js",
  "./js/ui.js",
  "./js/tasks.js",
  "./js/timer.js",
  "./js/timetable.js",
  "./js/courses.js",
  "./js/quizzes.js",
  "./js/grades.js",
  "./js/dashboard.js",
  "./js/io.js",
  "./js/main.js",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES)).catch(() => {})
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  // network-first for cross-origin (CDN libs, fonts) so they stay up to date when online;
  // cache-first for same-origin app shell so it works fully offline.
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) {
    event.respondWith(
      fetch(event.request).catch(() => caches.match(event.request))
    );
    return;
  }
  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});
