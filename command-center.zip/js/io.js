/* =========================================================================
   io.js — data portability. A single JSON bundle covers everything
   (tasks, time entries, settings, timetable, courses, projects, quizzes,
   grades) for full backup/restore; the original per-type CSV flow for
   tasks and time entries is kept and extended (now via PapaParse, which
   handles quoted commas etc. far more reliably than a manual split).
   ========================================================================= */

function downloadBlob(content, filename, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

/* ---------------- full JSON backup / restore ---------------- */
function exportAllJSON() {
  const bundle = {
    exportedAt: new Date().toISOString(), version: 2,
    tasks: DB.tasks, timeEntries: DB.timeEntries, runningEntry: DB.runningEntry, settings: DB.settings,
    timetable: DB.timetable, courses: DB.courses, projects: DB.projects, quizzes: DB.quizzes, grades: DB.grades,
  };
  downloadBlob(JSON.stringify(bundle, null, 2), "academic-command-center-backup.json", "application/json");
  toast("Backup downloaded.", { type: "success" });
}
async function importAllJSON(event) {
  const file = event.target.files[0];
  if (!file) return;
  const text = await file.text();
  let bundle;
  try { bundle = JSON.parse(text); } catch (e) {
    toast("That file isn't valid JSON.", { type: "danger" });
    event.target.value = ""; return;
  }
  const ok = await confirmModal({
    title: "Restore from backup?",
    message: "This replaces all current data in this browser with the contents of the backup file.",
    confirmLabel: "Restore",
  });
  if (!ok) { event.target.value = ""; return; }
  DB.tasks = bundle.tasks || [];
  DB.timeEntries = bundle.timeEntries || [];
  DB.runningEntry = bundle.runningEntry || null;
  DB.settings = Object.assign({}, DEFAULT_SETTINGS, bundle.settings || {});
  DB.timetable = bundle.timetable || [];
  DB.courses = bundle.courses || [];
  DB.projects = bundle.projects || [];
  DB.quizzes = bundle.quizzes || [];
  DB.grades = bundle.grades || [];
  saveAll();
  migrate();
  applyDarkMode();
  renderTasks(); renderLog(); renderTimerView(); renderTimetable(); renderCourses(); renderDashboard();
  refreshTaskLinkDropdowns(); refreshCourseDatalist();
  toast("Backup restored.", { type: "success" });
  event.target.value = "";
}

/* ---------------- per-type CSV templates ---------------- */
function downloadCSV(filename, headers, example) {
  const csv = Papa.unparse({ fields: headers, data: [example] });
  downloadBlob(csv, filename, "text/csv");
}
function downloadTasksTemplate() {
  downloadCSV("tasks_template.csv",
    ["taskName", "category", "course", "priority", "dueDate(YYYY-MM-DD)", "recurring(None/Daily/Weekly)", "notes"],
    ["Finish DCF model", "Studies", "Financial Management", "High", "2026-09-25", "Weekly", "Check WACC assumptions with professor"]);
}
function downloadTimeTemplate() {
  downloadCSV("time_log_template.csv",
    ["date(YYYY-MM-DD)", "startTime(HH:MM)", "endTime(HH:MM)", "category", "description", "linkedTaskName(optional)"],
    ["2026-09-18", "09:00", "10:30", "Studies", "Revised FM formulas", ""]);
}

/* ---------------- per-type CSV import (PapaParse) ---------------- */
function importTasksCSV(event) {
  const file = event.target.files[0];
  if (!file) return;
  Papa.parse(file, {
    header: true, skipEmptyLines: true,
    complete: (res) => {
      let added = 0;
      res.data.forEach((r) => {
        const name = r.taskName;
        if (!name) return;
        const courseVal = (r.course || "").trim();
        DB.tasks.push({
          id: uid("t"), taskName: name, category: r.category || "Other",
          course: courseVal ? getOrCreateCourse(courseVal).name : null,
          priority: r.priority || "Medium",
          dueDate: r["dueDate(YYYY-MM-DD)"] || r.dueDate || "",
          recurring: r["recurring(None/Daily/Weekly)"] || r.recurring || "None",
          notes: r.notes || "", isUrgent: false, isImportant: false, completed: false,
          subtasks: [], projectId: null, assignee: "", notifiedAt: null,
        });
        added++;
      });
      saveTasks(); renderTasks(); refreshTaskLinkDropdowns();
      toast(`Imported ${added} task(s).`, { type: added ? "success" : "warning" });
      event.target.value = "";
    },
  });
}
function importTimeCSV(event) {
  const file = event.target.files[0];
  if (!file) return;
  Papa.parse(file, {
    header: true, skipEmptyLines: true,
    complete: (res) => {
      let added = 0, skipped = 0;
      res.data.forEach((r) => {
        const date = r["date(YYYY-MM-DD)"] || r.date;
        const startT = r["startTime(HH:MM)"] || r.startTime;
        const endT = r["endTime(HH:MM)"] || r.endTime;
        if (!date || !startT || !endT) { skipped++; return; }
        const start = new Date(`${date}T${startT}`).getTime();
        const end = new Date(`${date}T${endT}`).getTime();
        if (isNaN(start) || isNaN(end) || end <= start) { skipped++; return; }
        const linkedName = (r["linkedTaskName(optional)"] || r.linkedTaskName || "").trim();
        const linkedTask = linkedName ? DB.tasks.find((t) => t.taskName.toLowerCase() === linkedName.toLowerCase()) : null;
        DB.timeEntries.push({
          id: uid("e"), taskId: linkedTask ? linkedTask.id : null, category: r.category || "Other",
          description: r.description || "", date, start, end, duration: end - start, source: "manual", mode: "manual",
        });
        added++;
      });
      saveTimeEntries(); renderLog(); renderTasks();
      toast(`Imported ${added} entr${added === 1 ? "y" : "ies"}.${skipped ? " Skipped " + skipped + " invalid row(s)." : ""}`, { type: added ? "success" : "warning" });
      event.target.value = "";
    },
  });
}
