/* =========================================================================
   tasks.js — task list, subtasks/checklists, filters, and the Eisenhower
   Matrix, which is rendered from the exact same DB.tasks array (no
   separate data source, just a different bucketing of the same items).
   ========================================================================= */

let taskViewMode = "list";      // "list" | "matrix"
const expandedTasks = new Set(); // task ids whose subtask panel is open
let editingTaskId = null;

/* ---------------- add / complete / delete ---------------- */
function addTask() {
  const taskName = document.getElementById("taskName").value.trim();
  if (!taskName) { toast("Give the task a name first.", { type: "warning" }); return; }
  const category = getCategoryValue("task");
  const courseName = document.getElementById("taskCourse").value.trim();
  const course = courseName ? getOrCreateCourse(courseName).name : null;
  const priority = document.getElementById("priority").value;
  const dueDate = document.getElementById("dueDate").value;
  const recurring = document.getElementById("taskRecurring").value;
  const notes = document.getElementById("taskNotes").value.trim();
  const isUrgent = document.getElementById("taskUrgent").checked;
  const isImportant = document.getElementById("taskImportant").checked;

  DB.tasks.push({
    id: uid("t"), taskName, category, course, priority, dueDate, recurring, notes,
    isUrgent, isImportant, completed: false, subtasks: [],
    projectId: null, assignee: "", notifiedAt: null,
  });
  saveTasks();
  document.getElementById("taskName").value = "";
  document.getElementById("taskNotes").value = "";
  document.getElementById("taskUrgent").checked = false;
  document.getElementById("taskImportant").checked = false;
  toast(`Added "${escapeHtml(taskName)}".`, { type: "success" });
  renderTasks();
  if (window.refreshTaskLinkDropdowns) refreshTaskLinkDropdowns();
  if (window.refreshCourseDatalist) refreshCourseDatalist();
}

function toggleTask(id) {
  const task = DB.tasks.find((t) => t.id === id);
  if (!task) return;
  task.completed = !task.completed;
  if (task.completed) {
    playCompleteSound && playCompleteSound();
    if (task.recurring && task.recurring !== "None") {
      const days = task.recurring === "Daily" ? 1 : 7;
      DB.tasks.push({
        id: uid("t"), taskName: task.taskName, category: task.category, course: task.course,
        priority: task.priority, dueDate: shiftDate(task.dueDate, days), recurring: task.recurring,
        notes: task.notes, isUrgent: task.isUrgent, isImportant: task.isImportant, completed: false,
        subtasks: (task.subtasks || []).map((s) => ({ id: uid("s"), title: s.title, completed: false })),
        projectId: task.projectId, assignee: task.assignee, notifiedAt: null,
      });
      toast(`Done! Next "${escapeHtml(task.taskName)}" scheduled for ${shiftDate(task.dueDate, days)}.`, { type: "success" });
    }
  }
  saveTasks();
  renderTasks();
  if (window.refreshTaskLinkDropdowns) refreshTaskLinkDropdowns();
  if (window.renderCourses) renderCourses();
}

function deleteTask(id) {
  const idx = DB.tasks.findIndex((t) => t.id === id);
  if (idx === -1) return;
  const [removed] = DB.tasks.splice(idx, 1);
  saveTasks();
  renderTasks();
  if (window.refreshTaskLinkDropdowns) refreshTaskLinkDropdowns();
  toast(`Deleted "${escapeHtml(removed.taskName)}".`, {
    type: "danger",
    actionLabel: "Undo",
    actionFn: () => {
      DB.tasks.splice(idx, 0, removed);
      saveTasks();
      renderTasks();
      if (window.refreshTaskLinkDropdowns) refreshTaskLinkDropdowns();
    },
  });
}

function toggleUrgent(id) {
  const t = DB.tasks.find((x) => x.id === id); if (!t) return;
  t.isUrgent = !t.isUrgent; saveTasks(); renderTasks();
}
function toggleImportant(id) {
  const t = DB.tasks.find((x) => x.id === id); if (!t) return;
  t.isImportant = !t.isImportant; saveTasks(); renderTasks();
}

/* ---------------- inline edit ---------------- */
function startEditTask(id) { editingTaskId = id; renderTasks(); }
function cancelEditTask() { editingTaskId = null; renderTasks(); }
function saveEditTask(id) {
  const task = DB.tasks.find((t) => t.id === id);
  if (!task) return;
  task.taskName = document.getElementById("etname-" + id).value.trim() || task.taskName;
  task.category = document.getElementById("etcat-" + id).value;
  const courseVal = document.getElementById("etcourse-" + id).value.trim();
  task.course = courseVal ? getOrCreateCourse(courseVal).name : null;
  task.priority = document.getElementById("etpri-" + id).value;
  task.dueDate = document.getElementById("etdue-" + id).value;
  task.recurring = document.getElementById("etrec-" + id).value;
  task.notes = document.getElementById("etnotes-" + id).value.trim();
  task.isUrgent = document.getElementById("eturg-" + id).checked;
  task.isImportant = document.getElementById("etimp-" + id).checked;
  saveTasks();
  editingTaskId = null;
  renderTasks();
  if (window.refreshTaskLinkDropdowns) refreshTaskLinkDropdowns();
  if (window.refreshCourseDatalist) refreshCourseDatalist();
  toast("Task updated.", { type: "success" });
}

/* ---------------- subtasks / checklists ---------------- */
function toggleExpand(id) {
  expandedTasks.has(id) ? expandedTasks.delete(id) : expandedTasks.add(id);
  renderTasks();
}
function addSubtask(taskId) {
  const input = document.getElementById("subInput-" + taskId);
  const title = input.value.trim();
  if (!title) return;
  const t = DB.tasks.find((x) => x.id === taskId);
  t.subtasks.push({ id: uid("s"), title, completed: false });
  saveTasks();
  expandedTasks.add(taskId);
  renderTasks();
}
function toggleSubtask(taskId, subId) {
  const t = DB.tasks.find((x) => x.id === taskId);
  const s = t.subtasks.find((x) => x.id === subId);
  s.completed = !s.completed;
  saveTasks();
  expandedTasks.add(taskId);
  renderTasks();
}
function deleteSubtask(taskId, subId) {
  const t = DB.tasks.find((x) => x.id === taskId);
  t.subtasks = t.subtasks.filter((x) => x.id !== subId);
  saveTasks();
  expandedTasks.add(taskId);
  renderTasks();
}

/* ---------------- filters ---------------- */
function refreshTaskFilterOptions() {
  const catSel = document.getElementById("filterCategory");
  const courseSel = document.getElementById("filterCourse");
  const curCat = catSel.value, curCourse = courseSel.value;
  catSel.innerHTML = `<option value="">All categories</option>` + getCategories().map((c) => `<option value="${escapeHtml(c.name)}">${c.emoji} ${escapeHtml(c.name)}</option>`).join("");
  courseSel.innerHTML = `<option value="">All courses</option>` + DB.courses.map((c) => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join("");
  if ([...catSel.options].some((o) => o.value === curCat)) catSel.value = curCat;
  if ([...courseSel.options].some((o) => o.value === curCourse)) courseSel.value = curCourse;
}
function getFilteredTasks() {
  const search = (document.getElementById("search").value || "").toLowerCase();
  const cat = document.getElementById("filterCategory").value;
  const course = document.getElementById("filterCourse").value;
  const pri = document.getElementById("filterPriority").value;
  const status = document.getElementById("filterStatus").value;
  return DB.tasks.filter((t) => {
    if (search && !t.taskName.toLowerCase().includes(search)) return false;
    if (cat && t.category !== cat) return false;
    if (course && t.course !== course) return false;
    if (pri && t.priority !== pri) return false;
    if (status === "pending" && t.completed) return false;
    if (status === "completed" && !t.completed) return false;
    return true;
  });
}

/* ---------------- due-date chip ---------------- */
function dueChipHtml(dueDate) {
  if (!dueDate) return `<span class="chip chip-neutral">No date</span>`;
  const d = daysUntil(dueDate);
  if (d < 0) return `<span class="chip chip-overdue">Overdue ${Math.abs(d)}d</span>`;
  if (d === 0) return `<span class="chip chip-today">Due today</span>`;
  if (d <= 3) return `<span class="chip chip-soon">Due in ${d}d</span>`;
  return `<span class="chip chip-far">${dueDate}</span>`;
}

function computeTaskTrackedTime(taskId) {
  return DB.timeEntries.filter((e) => e.taskId === taskId && e.end != null).reduce((s, e) => s + e.duration, 0);
}

/* ---------------- view mode ---------------- */
function setTaskViewMode(mode) {
  taskViewMode = mode;
  document.getElementById("viewListBtn").classList.toggle("active", mode === "list");
  document.getElementById("viewMatrixBtn").classList.toggle("active", mode === "matrix");
  renderTasks();
}
function quickFillTask(category) {
  showTab("tasks");
  document.getElementById("taskCategory").value = category;
  document.getElementById("taskName").focus();
}

/* ---------------- render: dispatcher ---------------- */
function renderTasks() {
  refreshTaskFilterOptions();
  const list = getFilteredTasks();
  const listWrap = document.getElementById("taskListWrap");
  const matrixWrap = document.getElementById("eisenhowerGrid");
  if (taskViewMode === "matrix") {
    listWrap.style.display = "none";
    matrixWrap.style.display = "grid";
    renderEisenhowerMatrix(list);
  } else {
    listWrap.style.display = "block";
    matrixWrap.style.display = "none";
    renderTaskListView(list);
  }
  document.getElementById("totalTasks").innerText = DB.tasks.length;
  document.getElementById("completedTasks").innerText = DB.tasks.filter((t) => t.completed).length;
  document.getElementById("pendingTasks").innerText = DB.tasks.filter((t) => !t.completed).length;
}

/* ---------------- render: list view ---------------- */
function renderTaskListView(list) {
  const table = document.getElementById("taskTable");
  const empty = document.getElementById("tasksEmptyState");
  table.innerHTML = "";

  if (DB.tasks.length === 0) {
    document.getElementById("tasksTableWrap").style.display = "none";
    empty.innerHTML = `
    <div class="empty-state">
      <div class="empty-illustration">📝</div>
      <p>No tasks yet. Add your first one above, or try a suggestion:</p>
      <div class="suggestions">
        <button class="chip-btn" onclick="quickFillTask('Studies')">📚 Study task</button>
        <button class="chip-btn" onclick="quickFillTask('Placement Prep')">💼 Placement prep</button>
        <button class="chip-btn" onclick="quickFillTask('Committee Work')">🤝 Committee task</button>
      </div>
    </div>`;
    return;
  }
  document.getElementById("tasksTableWrap").style.display = "table";
  empty.innerHTML = list.length ? "" : `<div class="empty-state"><p>No tasks match these filters.</p></div>`;

  list.forEach((task) => {
    const meta = getCategoryMeta(task.category);
    const tracked = computeTaskTrackedTime(task.id);
    const subDone = (task.subtasks || []).filter((s) => s.completed).length;
    const subTotal = (task.subtasks || []).length;

    if (editingTaskId === task.id) {
      table.innerHTML += `
      <tr class="edit-row">
        <td colspan="8">
          <div class="edit-grid">
            <div><label class="field-label">Task name</label><input type="text" id="etname-${task.id}" value="${escapeHtml(task.taskName)}"></div>
            <div><label class="field-label">Category</label><select id="etcat-${task.id}">${CATEGORY_OPTIONS_FOR(task.category)}</select></div>
            <div><label class="field-label">Course</label><input list="courseDatalist" id="etcourse-${task.id}" value="${escapeHtml(task.course || "")}"></div>
            <div><label class="field-label">Priority</label>
              <select id="etpri-${task.id}">
                <option value="High" ${task.priority === "High" ? "selected" : ""}>High</option>
                <option value="Medium" ${task.priority === "Medium" ? "selected" : ""}>Medium</option>
                <option value="Low" ${task.priority === "Low" ? "selected" : ""}>Low</option>
              </select>
            </div>
            <div><label class="field-label">Due date</label><input type="date" id="etdue-${task.id}" value="${task.dueDate || ""}"></div>
            <div><label class="field-label">Recurring</label>
              <select id="etrec-${task.id}">
                <option value="None" ${task.recurring === "None" ? "selected" : ""}>One-time</option>
                <option value="Daily" ${task.recurring === "Daily" ? "selected" : ""}>Daily</option>
                <option value="Weekly" ${task.recurring === "Weekly" ? "selected" : ""}>Weekly</option>
              </select>
            </div>
            <div class="span2"><label class="field-label">Notes / next steps</label><textarea id="etnotes-${task.id}">${escapeHtml(task.notes || "")}</textarea></div>
            <div><label class="flag-label"><input type="checkbox" id="eturg-${task.id}" ${task.isUrgent ? "checked" : ""}> Urgent</label></div>
            <div><label class="flag-label"><input type="checkbox" id="etimp-${task.id}" ${task.isImportant ? "checked" : ""}> Important</label></div>
          </div>
          <div class="edit-actions">
            <button class="btn save-btn" onclick="saveEditTask('${task.id}')">Save</button>
            <button class="btn ghost-btn" onclick="cancelEditTask()">Cancel</button>
          </div>
        </td>
      </tr>`;
      return;
    }

    table.innerHTML += `
    <tr class="${task.completed ? "row-completed" : ""}">
      <td class="task-name-cell">
        <label class="check-wrap">
          <input type="checkbox" ${task.completed ? "checked" : ""} onchange="toggleTask('${task.id}')">
          <span class="checkmark"></span>
        </label>
        <div>
          <div class="task-name ${task.completed ? "completed" : ""}">${escapeHtml(task.taskName)}</div>
          ${task.projectId ? `<div class="task-sub-meta">🗂️ ${projectBadge(task.projectId, task.assignee)}</div>` : ""}
          ${task.notes ? `<div class="task-notes">📝 ${escapeHtml(task.notes)}</div>` : ""}
          ${subTotal > 0 ? `<button class="link-btn" onclick="toggleExpand('${task.id}')">${subDone}/${subTotal} subtasks ${expandedTasks.has(task.id) ? "▲" : "▼"}</button>` : `<button class="link-btn" onclick="toggleExpand('${task.id}')">+ checklist</button>`}
          <span class="flag-row">
            <button class="flag-btn ${task.isUrgent ? "active-urgent" : ""}" title="Toggle urgent" onclick="toggleUrgent('${task.id}')">🔥</button>
            <button class="flag-btn ${task.isImportant ? "active-important" : ""}" title="Toggle important" onclick="toggleImportant('${task.id}')">⭐</button>
          </span>
          ${expandedTasks.has(task.id) ? subtaskPanelHtml(task) : ""}
        </div>
      </td>
      <td><span class="cat-tag" style="background:${meta.color}">${meta.emoji} ${escapeHtml(task.category)}</span></td>
      <td>${task.course ? `<span class="course-tag">${escapeHtml(task.course)}</span>` : "-"}</td>
      <td class="priority-${task.priority.toLowerCase()}">${task.priority}</td>
      <td>${dueChipHtml(task.dueDate)}${task.recurring !== "None" ? `<div class="hint">🔁 ${task.recurring}</div>` : ""}</td>
      <td>${tracked > 0 ? formatDuration(tracked) : "-"}</td>
      <td>${task.completed ? "Completed" : "Pending"}</td>
      <td class="actions-cell">
        <button class="icon-btn" title="Edit" onclick="startEditTask('${task.id}')">✎</button>
        <button class="icon-btn danger" title="Delete" onclick="deleteTask('${task.id}')">🗑</button>
      </td>
    </tr>`;
  });
}
function CATEGORY_OPTIONS_FOR(selected) {
  return getCategories().map((c) => `<option value="${escapeHtml(c.name)}" ${c.name === selected ? "selected" : ""}>${c.emoji} ${escapeHtml(c.name)}</option>`).join("");
}
function projectBadge(projectId, assignee) {
  const p = DB.projects.find((x) => x.id === projectId);
  if (!p) return "";
  return `${escapeHtml(p.name)}${assignee ? " · " + escapeHtml(assignee) : ""}`;
}
function subtaskPanelHtml(task) {
  const items = (task.subtasks || []).map((s) => `
    <li class="${s.completed ? "sub-done" : ""}">
      <label class="check-wrap small">
        <input type="checkbox" ${s.completed ? "checked" : ""} onchange="toggleSubtask('${task.id}','${s.id}')">
        <span class="checkmark"></span>
      </label>
      <span>${escapeHtml(s.title)}</span>
      <button class="icon-btn tiny danger" onclick="deleteSubtask('${task.id}','${s.id}')">✕</button>
    </li>`).join("");
  return `
  <div class="subtask-panel">
    <ul class="subtask-list">${items}</ul>
    <div class="subtask-add">
      <input type="text" id="subInput-${task.id}" placeholder="Add a checklist item" onkeydown="if(event.key==='Enter')addSubtask('${task.id}')">
      <button class="chip-btn" onclick="addSubtask('${task.id}')">Add</button>
    </div>
  </div>`;
}

/* ---------------- render: Eisenhower matrix ---------------- */
function renderEisenhowerMatrix(list) {
  const buckets = { q1: [], q2: [], q3: [], q4: [] };
  list.filter((t) => !t.completed).forEach((t) => {
    if (t.isUrgent && t.isImportant) buckets.q1.push(t);
    else if (!t.isUrgent && t.isImportant) buckets.q2.push(t);
    else if (t.isUrgent && !t.isImportant) buckets.q3.push(t);
    else buckets.q4.push(t);
  });
  const card = (t) => {
    const meta = getCategoryMeta(t.category);
    return `<div class="matrix-card" style="border-left-color:${meta.color}">
      <div class="matrix-card-title">${escapeHtml(t.taskName)}</div>
      <div class="matrix-card-meta">${dueChipHtml(t.dueDate)}</div>
      <div class="matrix-card-actions">
        <button class="icon-btn tiny" onclick="toggleTask('${t.id}')" title="Complete">✓</button>
        <button class="icon-btn tiny" onclick="startEditTask('${t.id}'); setTaskViewMode('list')" title="Edit">✎</button>
      </div>
    </div>`;
  };
  const quad = (title, emoji, items, cls) => `
    <div class="matrix-quad ${cls}">
      <h4>${emoji} ${title} <span class="q-count">${items.length}</span></h4>
      <div class="matrix-list">${items.map(card).join("") || `<p class="hint">Nothing here.</p>`}</div>
    </div>`;
  document.getElementById("eisenhowerGrid").innerHTML =
    quad("Do First", "🔥", buckets.q1, "q1") +
    quad("Schedule", "🗓️", buckets.q2, "q2") +
    quad("Delegate", "🤝", buckets.q3, "q3") +
    quad("Later", "🧊", buckets.q4, "q4");
}

/* ---------------- due-date notifications (opt-in) ---------------- */
function checkDueNotifications() {
  if (!DB.settings.notificationsEnabled) return;
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const today = toDateStr(Date.now());
  DB.tasks.forEach((t) => {
    if (t.completed || !t.dueDate) return;
    const d = daysUntil(t.dueDate);
    if (d != null && d <= 1 && d >= 0 && t.notifiedAt !== today) {
      new Notification("Task due soon", { body: `${t.taskName} — ${d === 0 ? "due today" : "due tomorrow"}` });
      t.notifiedAt = today;
    }
  });
  saveTasks();
}
