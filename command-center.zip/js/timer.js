/* =========================================================================
   timer.js — the live timer (free-running or Pomodoro), quick-break
   buttons, the overrun reminder banner, manual past-entries, and the
   time log table. Pomodoro logs each work/break segment as its own
   time entry (mode: "pomodoro-work" / "pomodoro-break") so the
   dashboard's category math doesn't need special-casing.
   ========================================================================= */

let timerInterval = null;
let reminderBannerShown = false;
let editingLogId = null;

/* ---------------- sound (no audio files needed, works offline) ---------------- */
function beep(freq = 880, dur = 180) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    o.frequency.value = freq; g.gain.value = 0.07;
    o.start(); setTimeout(() => { o.stop(); ctx.close(); }, dur);
  } catch (e) { /* audio unavailable, fail silently */ }
}
function playCompleteSound() { beep(660, 160); setTimeout(() => beep(990, 160), 90); }

/* ---------------- task-link dropdowns (shared by live + manual forms) ---------------- */
function pendingTaskOptionsHtml() {
  let html = '<option value="">— No linked task —</option>';
  DB.tasks.filter((t) => !t.completed).forEach((t) => {
    html += `<option value="${t.id}">${escapeHtml(t.taskName)}</option>`;
  });
  return html;
}
function refreshTaskLinkDropdowns() {
  ["liveTaskLink", "manTaskLink"].forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    const current = el.value;
    el.innerHTML = pendingTaskOptionsHtml();
    if ([...el.options].some((o) => o.value === current)) el.value = current;
  });
}
function onTaskLinkChange(prefix) {
  const sel = document.getElementById(prefix + "TaskLink");
  const task = DB.tasks.find((t) => t.id === sel.value);
  if (!task) return;
  const descInput = document.getElementById(prefix + "Description");
  if (!descInput.value) descInput.value = task.taskName;
  if (task.category) {
    const known = getCategories().some((c) => c.name === task.category);
    document.getElementById(prefix + "Category").value = known ? task.category : "__custom__";
    toggleCustomCat(prefix);
    if (!known) document.getElementById(prefix + "CategoryOther").value = task.category;
  }
}

/* ---------------- live timer ---------------- */
function startTimer(mode) {
  if (DB.runningEntry) { toast("A timer is already running. Stop it first.", { type: "warning" }); return; }
  const taskId = document.getElementById("liveTaskLink").value || null;
  const category = getCategoryValue("live");
  const description = document.getElementById("liveDescription").value.trim();
  const entry = { taskId, category, description, start: Date.now(), reminderDismissedUntil: 0, mode: mode || "free" };
  if (entry.mode === "pomodoro") {
    entry.phase = "work";
    entry.phaseStart = Date.now();
    entry.workMinutes = DB.settings.pomodoroWorkMinutes;
    entry.breakMinutes = DB.settings.pomodoroBreakMinutes;
    entry.cycleCount = 1;
  }
  DB.runningEntry = entry;
  saveRunning();
  document.getElementById("liveDescription").value = "";
  reminderBannerShown = false;
  renderTimerView();
}
function quickStart(category, description) {
  if (DB.runningEntry) { toast("A timer is already running. Stop it first.", { type: "warning" }); return; }
  DB.runningEntry = { taskId: null, category, description, start: Date.now(), reminderDismissedUntil: 0, mode: "free" };
  saveRunning();
  reminderBannerShown = false;
  renderTimerView();
  toast(`${escapeHtml(description)} started.`, { duration: 2000 });
}
function makeEntry(r, start, end, modeTag, overrideCategory, overrideDescription) {
  return {
    id: uid("e"), taskId: r.taskId || null,
    category: overrideCategory !== undefined ? overrideCategory : r.category,
    description: overrideDescription !== undefined ? overrideDescription : r.description,
    date: toDateStr(start), start, end, duration: end - start, source: "live", mode: modeTag,
  };
}
function pushPomodoroSegment(r, endTs) {
  if (endTs <= r.phaseStart) return;
  const cat = r.phase === "work" ? r.category : "Relax Time";
  const desc = r.phase === "work" ? r.description : "Pomodoro break";
  DB.timeEntries.push(makeEntry(r, r.phaseStart, endTs, "pomodoro-" + r.phase, cat, desc));
}
function notifyPhaseChange(phase) {
  const msg = phase === "work" ? "Break's over — back to focus 🎯" : "Nice work — take a break ☕";
  toast(msg);
  beep(phase === "work" ? 740 : 520, 220);
  if ("Notification" in window && Notification.permission === "granted") {
    new Notification("Pomodoro", { body: msg });
  }
}
function stopTimer() {
  if (!DB.runningEntry) return;
  const r = DB.runningEntry;
  const end = Date.now();
  if (r.mode === "pomodoro") {
    pushPomodoroSegment(r, end);
  } else {
    DB.timeEntries.push(makeEntry(r, r.start, end, "free"));
  }
  DB.runningEntry = null;
  saveRunning(); saveTimeEntries();
  reminderBannerShown = false;
  document.getElementById("reminderBanner").classList.remove("show");
  renderTimerView(); renderLog(); renderTasks();
  if (window.renderDashboard) renderDashboard();
}
function dismissReminder() {
  reminderBannerShown = false;
  document.getElementById("reminderBanner").classList.remove("show");
  if (DB.runningEntry) {
    DB.runningEntry.reminderDismissedUntil = Date.now() + (DB.settings.reminderThresholdMinutes || 90) * 60000;
    saveRunning();
  }
}
function showReminderBanner() {
  if (reminderBannerShown) return;
  reminderBannerShown = true;
  const banner = document.getElementById("reminderBanner");
  banner.querySelector(".reminder-text").innerText =
    `⏰ You've been tracking "${DB.runningEntry.description || DB.runningEntry.category}" for over ${DB.settings.reminderThresholdMinutes || 90} minutes. Still going?`;
  banner.classList.add("show");
}
function setRingProgress(elId, pct) {
  const circle = document.getElementById(elId);
  if (!circle) return;
  const r = circle.r.baseVal.value;
  const c = 2 * Math.PI * r;
  circle.style.strokeDasharray = `${c} ${c}`;
  circle.style.strokeDashoffset = c - (Math.max(0, Math.min(100, pct)) / 100) * c;
}
function renderTimerView() {
  clearInterval(timerInterval);
  const idle = document.getElementById("liveIdleForm");
  const running = document.getElementById("liveRunningView");
  if (!DB.runningEntry) {
    idle.style.display = "block";
    running.style.display = "none";
    return;
  }
  idle.style.display = "none";
  running.style.display = "block";
  const r = DB.runningEntry;
  const ring = document.getElementById("timerRingFg");
  ring.classList.toggle("pulsing", r.mode === "free");

  const tick = () => {
    const now = Date.now();
    if (r.mode === "pomodoro") {
      const limitMs = (r.phase === "work" ? r.workMinutes : r.breakMinutes) * 60000;
      const elapsedPhase = now - r.phaseStart;
      if (elapsedPhase >= limitMs) {
        pushPomodoroSegment(r, r.phaseStart + limitMs);
        const finishedPhase = r.phase;
        r.phase = r.phase === "work" ? "break" : "work";
        if (finishedPhase === "break") r.cycleCount = (r.cycleCount || 1) + 1;
        r.phaseStart = r.phaseStart + limitMs;
        saveRunning(); saveTimeEntries(); renderLog();
        notifyPhaseChange(r.phase);
      }
      const pct = Math.min(100, Math.round(((now - r.phaseStart) / limitMs) * 100));
      setRingProgress("timerRingFg", pct);
      document.getElementById("timerDisplay").innerText = formatHMS(now - r.phaseStart);
      document.getElementById("runningLabel").innerText =
        `${r.phase === "work" ? "🎯 Focus" : "☕ Break"} · Cycle ${r.cycleCount} · ${r.category}${r.description ? " — " + r.description : ""}`;
    } else {
      setRingProgress("timerRingFg", 100);
      const elapsed = now - r.start;
      document.getElementById("timerDisplay").innerText = formatHMS(elapsed);
      document.getElementById("runningLabel").innerText = `${r.category}${r.description ? " — " + r.description : ""}`;
      const thresholdMs = (DB.settings.reminderThresholdMinutes || 90) * 60000;
      if (elapsed > thresholdMs && now > (r.reminderDismissedUntil || 0)) showReminderBanner();
    }
  };
  tick();
  timerInterval = setInterval(tick, 1000);
}

/* ---------------- manual entry ---------------- */
function addManualEntry() {
  const taskId = document.getElementById("manTaskLink").value || null;
  const category = getCategoryValue("man");
  const description = document.getElementById("manDescription").value.trim();
  const date = document.getElementById("manDate").value;
  const startT = document.getElementById("manStart").value;
  const endT = document.getElementById("manEnd").value;
  if (!date || !startT || !endT) { toast("Fill in date, start and end time.", { type: "warning" }); return; }
  const start = new Date(`${date}T${startT}`).getTime();
  const end = new Date(`${date}T${endT}`).getTime();
  if (end <= start) { toast("End time must be after start time.", { type: "warning" }); return; }
  DB.timeEntries.push({
    id: uid("e"), taskId, category, description, date, start, end,
    duration: end - start, source: "manual", mode: "manual",
  });
  saveTimeEntries();
  document.getElementById("manDescription").value = "";
  toast("Entry logged.", { type: "success" });
  renderLog(); renderTasks();
  if (window.renderDashboard) renderDashboard();
}

/* ---------------- time log ---------------- */
async function deleteEntry(id) {
  const ok = await confirmModal({ title: "Delete this time entry?", message: "This can't be undone.", confirmLabel: "Delete" });
  if (!ok) return;
  DB.timeEntries = DB.timeEntries.filter((e) => e.id !== id);
  saveTimeEntries(); renderLog(); renderTasks();
  toast("Time entry deleted.", { type: "danger" });
}
function startEditEntry(id) { editingLogId = id; renderLog(); }
function cancelEditEntry() { editingLogId = null; renderLog(); }
function saveEditEntry(id) {
  const entry = DB.timeEntries.find((e) => e.id === id);
  const date = document.getElementById("edit-date-" + id).value;
  const startT = document.getElementById("edit-start-" + id).value;
  const endT = document.getElementById("edit-end-" + id).value;
  const category = document.getElementById("edit-cat-" + id).value.trim();
  const description = document.getElementById("edit-desc-" + id).value.trim();
  const start = new Date(`${date}T${startT}`).getTime();
  const end = new Date(`${date}T${endT}`).getTime();
  if (end <= start) { toast("End time must be after start time.", { type: "warning" }); return; }
  entry.date = date; entry.start = start; entry.end = end; entry.duration = end - start;
  entry.category = category || entry.category; entry.description = description;
  saveTimeEntries();
  editingLogId = null;
  renderLog(); renderTasks();
  if (window.renderDashboard) renderDashboard();
  toast("Entry updated.", { type: "success" });
}
const MODE_ICON = { free: "▶️", manual: "✏️", "pomodoro-work": "🎯", "pomodoro-break": "☕" };
function renderLog() {
  const table = document.getElementById("logTable");
  const empty = document.getElementById("logEmptyState");
  table.innerHTML = "";
  const sorted = [...DB.timeEntries].sort((a, b) => b.start - a.start);

  empty.innerHTML = DB.timeEntries.length === 0 ? `
    <div class="empty-state">
      <div class="empty-illustration">⏱️</div>
      <p>No time logged yet. Start a live timer above, try a quick break, or add a past entry.</p>
      <div class="suggestions">
        <button class="chip-btn" onclick="quickStart('Relax Time','Break')">☕ Quick break</button>
        <button class="chip-btn" onclick="document.getElementById('manDescription').focus()">✏️ Log a past entry</button>
      </div>
    </div>` : "";

  sorted.forEach((entry) => {
    const meta = getCategoryMeta(entry.category);
    const linkedTask = entry.taskId ? DB.tasks.find((t) => t.id === entry.taskId) : null;
    if (editingLogId === entry.id) {
      table.innerHTML += `
      <tr class="edit-row">
        <td><input type="date" id="edit-date-${entry.id}" value="${entry.date}"></td>
        <td><input type="text" id="edit-cat-${entry.id}" value="${escapeHtml(entry.category)}"></td>
        <td><input type="text" id="edit-desc-${entry.id}" value="${escapeHtml(entry.description || "")}"></td>
        <td>${linkedTask ? escapeHtml(linkedTask.taskName) : "-"}</td>
        <td><input type="time" id="edit-start-${entry.id}" value="${toTimeStr(entry.start)}"></td>
        <td><input type="time" id="edit-end-${entry.id}" value="${toTimeStr(entry.end)}"></td>
        <td>-</td>
        <td>
          <button class="btn save-btn" onclick="saveEditEntry('${entry.id}')">Save</button>
          <button class="btn ghost-btn" onclick="cancelEditEntry()">Cancel</button>
        </td>
      </tr>`;
    } else {
      table.innerHTML += `
      <tr>
        <td>${entry.date}</td>
        <td><span class="cat-tag" style="background:${meta.color}">${meta.emoji} ${escapeHtml(entry.category)}</span></td>
        <td>${MODE_ICON[entry.mode] || ""} ${escapeHtml(entry.description || "-")}</td>
        <td>${linkedTask ? "🔗 " + escapeHtml(linkedTask.taskName) : "-"}</td>
        <td>${toDisplayTime(entry.start)}</td>
        <td>${toDisplayTime(entry.end)}</td>
        <td>${formatDuration(entry.duration)}</td>
        <td class="actions-cell">
          <button class="icon-btn" title="Edit" onclick="startEditEntry('${entry.id}')">✎</button>
          <button class="icon-btn danger" title="Delete" onclick="deleteEntry('${entry.id}')">🗑</button>
        </td>
      </tr>`;
    }
  });
}
