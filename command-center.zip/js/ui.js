/* =========================================================================
   ui.js — shared UI primitives used by every tab: toasts (with optional
   Undo), a confirm modal (replaces window.confirm), tab switching, dark
   mode, and global keyboard shortcuts.
   ========================================================================= */

/* ---------------- toasts ---------------- */
let toastTimer = null;
function toast(message, opts = {}) {
  const { type = "default", actionLabel = null, actionFn = null, duration = 4500 } = opts;
  const container = document.getElementById("toastContainer");
  const el = document.createElement("div");
  el.className = `toast toast-${type}`;
  el.setAttribute("role", "status");
  el.innerHTML = `
    <span class="toast-msg">${message}</span>
    ${actionLabel ? `<button class="toast-action">${escapeHtml(actionLabel)}</button>` : ""}
    <button class="toast-close" aria-label="Dismiss">✕</button>
  `;
  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add("toast-in"));

  const remove = () => {
    el.classList.remove("toast-in");
    el.classList.add("toast-out");
    setTimeout(() => el.remove(), 220);
  };
  const timeoutId = setTimeout(remove, duration);

  if (actionLabel && actionFn) {
    el.querySelector(".toast-action").addEventListener("click", () => {
      clearTimeout(timeoutId);
      actionFn();
      remove();
    });
  }
  el.querySelector(".toast-close").addEventListener("click", () => {
    clearTimeout(timeoutId);
    remove();
  });
}

/* ---------------- confirm modal (replaces window.confirm) ---------------- */
function confirmModal({ title = "Are you sure?", message = "", confirmLabel = "Confirm", danger = true } = {}) {
  return new Promise((resolve) => {
    const overlay = document.getElementById("modalOverlay");
    overlay.innerHTML = `
      <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
        <h3 id="modalTitle">${escapeHtml(title)}</h3>
        <p class="modal-msg">${message}</p>
        <div class="modal-actions">
          <button class="btn ghost-btn" id="modalCancel">Cancel</button>
          <button class="btn ${danger ? "danger-btn" : "add-btn"}" id="modalConfirm">${escapeHtml(confirmLabel)}</button>
        </div>
      </div>`;
    overlay.classList.add("open");
    const cleanup = (result) => {
      overlay.classList.remove("open");
      overlay.innerHTML = "";
      document.removeEventListener("keydown", escHandler);
      resolve(result);
    };
    const escHandler = (e) => { if (e.key === "Escape") cleanup(false); };
    document.addEventListener("keydown", escHandler);
    overlay.querySelector("#modalCancel").addEventListener("click", () => cleanup(false));
    overlay.querySelector("#modalConfirm").addEventListener("click", () => cleanup(true));
    overlay.querySelector("#modalConfirm").focus();
    overlay.addEventListener("click", (e) => { if (e.target === overlay) cleanup(false); }, { once: true });
  });
}

/* ---------------- tabs ---------------- */
const TAB_IDS = ["dashboard", "tasks", "timetable", "courses", "tracker"];
function showTab(name) {
  TAB_IDS.forEach((t) => {
    const panel = document.getElementById(t + "Tab");
    const btn = document.getElementById("btn-" + t);
    if (!panel || !btn) return;
    panel.classList.toggle("active", t === name);
    btn.classList.toggle("active", t === name);
    btn.setAttribute("aria-selected", t === name ? "true" : "false");
  });
  if (name === "dashboard" && window.renderDashboard) renderDashboard();
  if (name === "timetable" && window.renderTimetable) renderTimetable();
  if (name === "courses" && window.renderCourses) renderCourses();
  localStorage.setItem("lastTab", name);
}

/* ---------------- sub-tabs (used inside Courses & Projects) ---------------- */
function showSubTab(group, name) {
  document.querySelectorAll(`[data-subtab-panel="${group}"]`).forEach((p) => {
    p.classList.toggle("active", p.dataset.subtab === name);
  });
  document.querySelectorAll(`[data-subtab-btn="${group}"]`).forEach((b) => {
    b.classList.toggle("active", b.dataset.subtab === name);
  });
}

/* ---------------- dark mode ---------------- */
function toggleDarkMode() {
  DB.settings.darkMode = !DB.settings.darkMode;
  applyDarkMode();
  saveSettings();
}
function applyDarkMode() {
  document.body.classList.toggle("dark", DB.settings.darkMode);
  const btn = document.getElementById("darkToggleBtn");
  if (btn) btn.innerHTML = DB.settings.darkMode ? "☀️" : "🌙";
}

/* ---------------- category select helper (select + "custom" text fallback) ---------------- */
function toggleCustomCat(prefix) {
  const sel = document.getElementById(prefix + "Category");
  const other = document.getElementById(prefix + "CategoryOther");
  if (!sel || !other) return;
  other.style.display = sel.value === "__custom__" ? "inline-block" : "none";
}
function getCategoryValue(prefix) {
  const sel = document.getElementById(prefix + "Category");
  if (sel.value === "__custom__") {
    const custom = document.getElementById(prefix + "CategoryOther").value.trim();
    if (custom) addCustomCategory(custom);
    return custom || "Other";
  }
  return sel.value;
}
function categorySelectHtml(selected) {
  return categoryOptionsHtml(selected) + `<option value="__custom__">✏️ Add custom category…</option>`;
}

/* ---------------- keyboard shortcuts ---------------- */
document.addEventListener("keydown", (e) => {
  const tag = (e.target.tagName || "").toLowerCase();
  const typing = tag === "input" || tag === "textarea" || e.target.isContentEditable;
  if (e.key === "/" && !typing) {
    e.preventDefault();
    showTab("tasks");
    document.getElementById("search").focus();
  }
  if ((e.key === "n" || e.key === "N") && !typing) {
    e.preventDefault();
    showTab("tasks");
    document.getElementById("taskName").focus();
  }
  if (e.key === "Escape") {
    const overlay = document.getElementById("modalOverlay");
    if (overlay && overlay.classList.contains("open")) overlay.classList.remove("open");
  }
});
