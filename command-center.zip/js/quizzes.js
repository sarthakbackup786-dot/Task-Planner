/* =========================================================================
   quizzes.js — lightweight exam-prep tracker: mark a topic reviewed,
   log scores across multiple attempts.
   ========================================================================= */

function addQuizTopic() {
  const course = document.getElementById("quizCourse").value.trim();
  const topic = document.getElementById("quizTopic").value.trim();
  if (!topic) { toast("Give the topic a name.", { type: "warning" }); return; }
  if (course) getOrCreateCourse(course);
  DB.quizzes.push({ id: uid("q"), course: course || null, topic, reviewed: false, attempts: [] });
  saveQuizzes();
  document.getElementById("quizTopic").value = "";
  renderQuizzes();
  toast("Topic added.", { type: "success" });
}
function toggleQuizReviewed(id) {
  const q = DB.quizzes.find((x) => x.id === id);
  q.reviewed = !q.reviewed;
  saveQuizzes(); renderQuizzes();
}
function addQuizAttempt(id) {
  const q = DB.quizzes.find((x) => x.id === id);
  const score = parseFloat(document.getElementById("qscore-" + id).value);
  const maxScore = parseFloat(document.getElementById("qmax-" + id).value);
  if (isNaN(score) || isNaN(maxScore) || maxScore <= 0) { toast("Enter a valid score and max score.", { type: "warning" }); return; }
  q.attempts.push({ date: toDateStr(Date.now()), score, maxScore });
  saveQuizzes();
  document.getElementById("qscore-" + id).value = "";
  document.getElementById("qmax-" + id).value = "";
  renderQuizzes();
  toast("Attempt logged.", { type: "success" });
}
async function deleteQuiz(id) {
  const ok = await confirmModal({ title: "Delete this topic?", message: "All logged attempts for it will be removed.", confirmLabel: "Delete" });
  if (!ok) return;
  DB.quizzes = DB.quizzes.filter((q) => q.id !== id);
  saveQuizzes(); renderQuizzes();
  toast("Topic deleted.", { type: "danger" });
}
function renderQuizzes() {
  const wrap = document.getElementById("quizListWrap");
  if (!wrap) return;
  if (!DB.quizzes.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="empty-illustration">🧠</div><p>No topics yet. Add one below to start tracking review status and quiz scores.</p></div>`;
    return;
  }
  wrap.innerHTML = DB.quizzes.map((q) => {
    const last = q.attempts[q.attempts.length - 1];
    const avg = q.attempts.length ? q.attempts.reduce((s, a) => s + a.score / a.maxScore, 0) / q.attempts.length : null;
    return `<div class="quiz-card ${q.reviewed ? "reviewed" : ""}">
      <div class="quiz-head">
        <label class="check-wrap small"><input type="checkbox" ${q.reviewed ? "checked" : ""} onchange="toggleQuizReviewed('${q.id}')"><span class="checkmark"></span></label>
        <div>
          <div class="quiz-topic">${escapeHtml(q.topic)}</div>
          ${q.course ? `<span class="course-tag">${escapeHtml(q.course)}</span>` : ""}
        </div>
        <button class="icon-btn tiny danger" onclick="deleteQuiz('${q.id}')">🗑</button>
      </div>
      <div class="quiz-stats">
        <span>${q.attempts.length} attempt${q.attempts.length === 1 ? "" : "s"}</span>
        ${last ? `<span>Last: ${last.score}/${last.maxScore}</span>` : ""}
        ${avg != null ? `<span>Avg: ${Math.round(avg * 100)}%</span>` : ""}
      </div>
      <div class="quiz-attempt-form">
        <input type="number" id="qscore-${q.id}" placeholder="Score" step="0.5">
        <input type="number" id="qmax-${q.id}" placeholder="Out of" step="0.5">
        <button class="chip-btn" onclick="addQuizAttempt('${q.id}')">Log attempt</button>
      </div>
    </div>`;
  }).join("");
}
