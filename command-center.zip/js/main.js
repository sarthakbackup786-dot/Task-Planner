/* =========================================================================
   main.js — bootstraps the app once the DOM is ready. Everything else
   (state, rendering, event handlers) is already defined by the time this
   runs; this file just wires the initial paint and background timers.
   ========================================================================= */

document.addEventListener("DOMContentLoaded", () => {
  ["taskCategory", "liveCategory", "manCategory"].forEach((id) => {
    document.getElementById(id).innerHTML = categorySelectHtml();
  });
  document.getElementById("categoryLegend").innerHTML = getCategories()
    .map((c) => `<span class="cat-tag" style="background:${c.color}">${c.emoji} ${escapeHtml(c.name)}</span>`).join("");
  document.getElementById("manDate").value = toDateStr(Date.now());

  refreshCourseDatalist();
  refreshTaskLinkDropdowns();
  applyDarkMode();

  renderTasks();
  renderLog();
  renderTimerView();
  renderTimetable();
  renderCourses();

  const lastTab = localStorage.getItem("lastTab") || "dashboard";
  showTab(lastTab);

  const skeleton = document.getElementById("appSkeleton");
  if (skeleton) skeleton.classList.add("hide");

  checkDueNotifications();
  setInterval(checkDueNotifications, 5 * 60 * 1000);

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js").catch(() => { /* offline support is best-effort */ });
  }
});
