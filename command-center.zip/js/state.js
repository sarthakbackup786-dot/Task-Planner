/* =========================================================================
   state.js — single source of truth.
   Every other module reads/writes through the DB object and Utils helpers
   defined here. localStorage keys are kept 1:1 with the old single-file
   build (tasks, timeEntries, runningEntry, settings) so existing data
   survives the upgrade untouched; new keys (timetable, courses, projects,
   quizzes, grades) are added alongside rather than replacing anything.
   ========================================================================= */

const DEFAULT_CATEGORIES = [
  { name: "Studies", color: "#4C6FFF", emoji: "📚" },
  { name: "Placement Prep", color: "#A855F7", emoji: "💼" },
  { name: "Committee Work", color: "#14B8A6", emoji: "🤝" },
  { name: "Meals", color: "#F59E0B", emoji: "🍽️" },
  { name: "Relax Time", color: "#22C55E", emoji: "🌿" },
  { name: "Other", color: "#6B7280", emoji: "✨" },
];

const DEFAULT_SETTINGS = {
  darkMode: false,
  dailyGoalMinutes: 240,
  weeklyGoalMinutes: 1200,
  reminderThresholdMinutes: 90,
  pomodoroWorkMinutes: 25,
  pomodoroBreakMinutes: 5,
  notificationsEnabled: false,
  categories: DEFAULT_CATEGORIES,
};

/* ---------------- storage helpers ---------------- */
const Store = {
  get(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.warn("Store.get failed for", key, e);
      return fallback;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.warn("Store.set failed for", key, e);
      return false;
    }
  },
};

/* ---------------- the DB ---------------- */
const DB = {
  tasks: Store.get("tasks", []),
  timeEntries: Store.get("timeEntries", []),
  runningEntry: Store.get("runningEntry", null),
  settings: Object.assign({}, DEFAULT_SETTINGS, Store.get("settings", {})),
  timetable: Store.get("timetable", []),   // [{id, day(0-6, Mon=0), start, end, courseId, room}]
  courses: Store.get("courses", []),       // [{id, name, color}]
  projects: Store.get("projects", []),     // [{id, name, courseId, teammates:[{id,name}]}]
  quizzes: Store.get("quizzes", []),       // [{id, courseId, topic, reviewed, attempts:[{date,score,maxScore}]}]
  grades: Store.get("grades", []),         // [{id, courseId, component, marks, maxMarks}]
};

function saveTasks() { Store.set("tasks", DB.tasks); }
function saveTimeEntries() { Store.set("timeEntries", DB.timeEntries); }
function saveRunning() { Store.set("runningEntry", DB.runningEntry); }
function saveSettings() { Store.set("settings", DB.settings); }
function saveTimetable() { Store.set("timetable", DB.timetable); }
function saveCourses() { Store.set("courses", DB.courses); }
function saveProjects() { Store.set("projects", DB.projects); }
function saveQuizzes() { Store.set("quizzes", DB.quizzes); }
function saveGrades() { Store.set("grades", DB.grades); }
function saveAll() {
  saveTasks(); saveTimeEntries(); saveRunning(); saveSettings();
  saveTimetable(); saveCourses(); saveProjects(); saveQuizzes(); saveGrades();
}

/* ---------------- migration: backfill fields old data won't have ---------------- */
function migrate() {
  let changed = false;
  DB.tasks.forEach((t, i) => {
    if (!t.id) { t.id = uid("t", i); changed = true; }
    if (t.category === undefined) { t.category = "Other"; changed = true; }
    if (t.recurring === undefined) { t.recurring = "None"; changed = true; }
    if (t.notes === undefined) { t.notes = ""; changed = true; }
    if (t.course === undefined) { t.course = null; changed = true; }
    if (t.projectId === undefined) { t.projectId = null; changed = true; }
    if (t.assignee === undefined) { t.assignee = ""; changed = true; }
    if (t.isUrgent === undefined) { t.isUrgent = false; changed = true; }
    if (t.isImportant === undefined) { t.isImportant = false; changed = true; }
    if (t.subtasks === undefined) { t.subtasks = []; changed = true; }
    if (t.notifiedAt === undefined) { t.notifiedAt = null; changed = true; }
  });
  DB.timeEntries.forEach((e) => {
    if (e.taskId === undefined) { e.taskId = null; changed = true; }
    if (e.mode === undefined) { e.mode = "free"; changed = true; }
  });
  if (!DB.settings.categories || !DB.settings.categories.length) {
    DB.settings.categories = DEFAULT_CATEGORIES;
    changed = true;
  }
  if (changed) saveAll();
}

/* ---------------- id / date / format utilities (shared everywhere) ---------------- */
function uid(prefix, salt) {
  return `${prefix}_${Date.now().toString(36)}_${(salt || 0)}${Math.random().toString(36).slice(2, 7)}`;
}
function pad(n) { return String(n).padStart(2, "0"); }
function toDateStr(ts) {
  const d = new Date(ts);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
function toTimeStr(ts) {
  const d = new Date(ts);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function toDisplayTime(ts) {
  return new Date(ts).toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}
function formatDuration(ms) {
  if (ms == null || ms < 0) return "-";
  const totalMin = Math.round(ms / 60000);
  const h = Math.floor(totalMin / 60), m = totalMin % 60;
  return (h > 0 ? h + "h " : "") + m + "m";
}
function formatHMS(ms) {
  const s = Math.floor(ms / 1000);
  return `${pad(Math.floor(s / 3600))}:${pad(Math.floor((s % 3600) / 60))}:${pad(s % 60)}`;
}
function shiftDate(dateStr, days) {
  const base = dateStr ? new Date(dateStr + "T00:00:00") : new Date();
  base.setDate(base.getDate() + days);
  return toDateStr(base.getTime());
}
function daysUntil(dateStr) {
  if (!dateStr) return null;
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const due = new Date(dateStr + "T00:00:00");
  return Math.round((due - today) / 86400000);
}
function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* ---------------- categories ---------------- */
function getCategories() { return DB.settings.categories; }
function getCategoryMeta(name) {
  return getCategories().find((c) => c.name === name) || { name, color: "#6B7280", emoji: "🏷️" };
}
function categoryOptionsHtml(selected) {
  return getCategories()
    .map((c) => `<option value="${escapeHtml(c.name)}" ${c.name === selected ? "selected" : ""}>${c.emoji} ${escapeHtml(c.name)}</option>`)
    .join("");
}
function addCustomCategory(name, color) {
  if (!name) return;
  if (getCategories().some((c) => c.name.toLowerCase() === name.toLowerCase())) return;
  const palette = ["#4C6FFF", "#A855F7", "#14B8A6", "#F59E0B", "#22C55E", "#EC4899", "#F97316", "#06B6D4"];
  const usedColor = color || palette[getCategories().length % palette.length];
  DB.settings.categories.push({ name, color: usedColor, emoji: "🏷️" });
  saveSettings();
}

/* ---------------- courses ---------------- */
function getOrCreateCourse(name) {
  if (!name) return null;
  let course = DB.courses.find((c) => c.name.toLowerCase() === name.toLowerCase());
  if (!course) {
    const palette = ["#4C6FFF", "#A855F7", "#14B8A6", "#F59E0B", "#EC4899", "#06B6D4", "#F97316", "#22C55E"];
    course = { id: uid("c"), name, color: palette[DB.courses.length % palette.length] };
    DB.courses.push(course);
    saveCourses();
  }
  return course;
}
function courseById(id) { return DB.courses.find((c) => c.id === id) || null; }

/* run migration immediately so every other module sees clean data */
migrate();
