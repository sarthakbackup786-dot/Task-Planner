/* =========================================================================
   grades.js — component-wise marks per course with a running total,
   visualized as a simple bar per course.
   ========================================================================= */

function addGrade() {
  const course = document.getElementById("gradeCourse").value.trim();
  const component = document.getElementById("gradeComponent").value.trim();
  const marks = parseFloat(document.getElementById("gradeMarks").value);
  const maxMarks = parseFloat(document.getElementById("gradeMax").value);
  if (!course || !component || isNaN(marks) || isNaN(maxMarks) || maxMarks <= 0) {
    toast("Fill in course, component, marks and max marks.", { type: "warning" }); return;
  }
  getOrCreateCourse(course);
  DB.grades.push({ id: uid("g"), course, component, marks, maxMarks });
  saveGrades();
  document.getElementById("gradeComponent").value = "";
  document.getElementById("gradeMarks").value = "";
  document.getElementById("gradeMax").value = "";
  renderGrades();
  toast("Grade logged.", { type: "success" });
}
async function deleteGrade(id) {
  const ok = await confirmModal({ title: "Delete this grade entry?", confirmLabel: "Delete" });
  if (!ok) return;
  DB.grades = DB.grades.filter((g) => g.id !== id);
  saveGrades(); renderGrades();
  toast("Grade entry deleted.", { type: "danger" });
}
function renderGrades() {
  const wrap = document.getElementById("gradesWrap");
  if (!wrap) return;
  if (!DB.grades.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="empty-illustration">🎯</div><p>No grades logged yet. Add component-wise marks below to see a running total per course.</p></div>`;
    return;
  }
  const byCourse = {};
  DB.grades.forEach((g) => { (byCourse[g.course] = byCourse[g.course] || []).push(g); });
  wrap.innerHTML = Object.entries(byCourse).map(([course, items]) => {
    const totalMarks = items.reduce((s, g) => s + g.marks, 0);
    const totalMax = items.reduce((s, g) => s + g.maxMarks, 0);
    const pct = totalMax ? Math.round((totalMarks / totalMax) * 100) : 0;
    return `<div class="grade-card">
      <h4>${escapeHtml(course)}</h4>
      <div class="bar-row"><div class="bar-track"><div class="bar-fill" style="width:${pct}%;background:${pct >= 60 ? "#22C55E" : pct >= 40 ? "#F59E0B" : "#EF4444"}"></div></div><div class="bar-value">${totalMarks}/${totalMax} (${pct}%)</div></div>
      <table class="grade-table">
        <thead><tr><th>Component</th><th>Marks</th><th></th></tr></thead>
        <tbody>${items.map((g) => `<tr><td>${escapeHtml(g.component)}</td><td>${g.marks}/${g.maxMarks}</td><td><button class="icon-btn tiny danger" onclick="deleteGrade('${g.id}')">✕</button></td></tr>`).join("")}</tbody>
      </table>
    </div>`;
  }).join("");
}
