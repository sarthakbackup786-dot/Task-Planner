/* =========================================================================
   courses.js — course roster (auto-populated from the timetable, or added
   manually) and Group Projects. A project's "sub-tasks" are plain tasks
   in DB.tasks with a projectId + assignee set — kept unified with the
   main task list rather than a parallel store, so completing one from
   either screen stays in sync automatically.
   ========================================================================= */

function refreshCourseDatalist() {
  const dl = document.getElementById("courseDatalist");
  if (dl) dl.innerHTML = DB.courses.map((c) => `<option value="${escapeHtml(c.name)}">`).join("");
}

/* ---------------- courses ---------------- */
function addCourseManual() {
  const name = document.getElementById("newCourseName").value.trim();
  if (!name) { toast("Course name required.", { type: "warning" }); return; }
  getOrCreateCourse(name);
  document.getElementById("newCourseName").value = "";
  renderCourses();
  toast("Course added.", { type: "success" });
}
async function deleteCourse(id) {
  const ok = await confirmModal({ title: "Remove this course?", message: "Tasks and timetable entries that reference it keep the course name as plain text.", confirmLabel: "Remove" });
  if (!ok) return;
  DB.courses = DB.courses.filter((c) => c.id !== id);
  saveCourses(); renderCourses();
  toast("Course removed.", { type: "danger" });
}
function renderCourseList() {
  const wrap = document.getElementById("courseListWrap");
  if (!DB.courses.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="empty-illustration">🎓</div><p>No courses yet. Add one below, assign a course to a task, or import your timetable and courses will appear automatically.</p></div>`;
    return;
  }
  wrap.innerHTML = `<div class="course-grid">${DB.courses.map((c) => {
    const related = DB.tasks.filter((t) => t.course === c.name);
    const pending = related.filter((t) => !t.completed).length;
    const tracked = related.reduce((s, t) => s + computeTaskTrackedTime(t.id), 0);
    const slots = DB.timetable.filter((s) => s.courseId === c.id).length;
    return `<div class="course-card" style="border-top-color:${c.color}">
      <h4>${escapeHtml(c.name)}</h4>
      <div class="course-stats">
        <span>${pending} pending</span>
        <span>${formatDuration(tracked)} tracked</span>
        <span>${slots}/wk class${slots === 1 ? "" : "es"}</span>
      </div>
      <button class="icon-btn tiny danger" onclick="deleteCourse('${c.id}')">🗑 Remove</button>
    </div>`;
  }).join("")}</div>`;
}

/* ---------------- group projects ---------------- */
function addProject() {
  const name = document.getElementById("newProjectName").value.trim();
  const courseName = document.getElementById("newProjectCourse").value.trim();
  if (!name) { toast("Project name required.", { type: "warning" }); return; }
  const courseId = courseName ? getOrCreateCourse(courseName).id : null;
  DB.projects.push({ id: uid("p"), name, courseId, teammates: [] });
  saveProjects();
  document.getElementById("newProjectName").value = "";
  document.getElementById("newProjectCourse").value = "";
  renderProjects();
  if (window.refreshCourseDatalist) refreshCourseDatalist();
  toast("Project created.", { type: "success" });
}
async function deleteProject(id) {
  const ok = await confirmModal({ title: "Delete this project?", message: "Tasks linked to it stay in your task list but lose their project link.", confirmLabel: "Delete" });
  if (!ok) return;
  DB.projects = DB.projects.filter((p) => p.id !== id);
  DB.tasks.forEach((t) => { if (t.projectId === id) { t.projectId = null; t.assignee = ""; } });
  saveProjects(); saveTasks();
  renderProjects(); renderTasks();
  toast("Project deleted.", { type: "danger" });
}
function addTeammate(projectId) {
  const input = document.getElementById("teammateInput-" + projectId);
  const name = input.value.trim();
  if (!name) return;
  const project = DB.projects.find((p) => p.id === projectId);
  project.teammates.push({ id: uid("m"), name });
  saveProjects(); input.value = ""; renderProjects();
}
function removeTeammate(projectId, teammateId) {
  const project = DB.projects.find((p) => p.id === projectId);
  project.teammates = project.teammates.filter((m) => m.id !== teammateId);
  saveProjects(); renderProjects();
}
function addProjectTask(projectId) {
  const titleInput = document.getElementById("ptaskInput-" + projectId);
  const assigneeSel = document.getElementById("ptaskAssignee-" + projectId);
  const title = titleInput.value.trim();
  if (!title) return;
  const project = DB.projects.find((p) => p.id === projectId);
  const course = project.courseId ? courseById(project.courseId) : null;
  DB.tasks.push({
    id: uid("t"), taskName: title, category: "Committee Work", course: course ? course.name : null,
    priority: "Medium", dueDate: "", recurring: "None", notes: "", isUrgent: false, isImportant: false,
    completed: false, subtasks: [], projectId, assignee: assigneeSel.value || "", notifiedAt: null,
  });
  saveTasks();
  titleInput.value = "";
  renderProjects();
  if (window.renderTasks) renderTasks();
  if (window.refreshTaskLinkDropdowns) refreshTaskLinkDropdowns();
  toast("Task added to project.", { type: "success" });
}
function renderProjects() {
  const wrap = document.getElementById("projectListWrap");
  if (!DB.projects.length) {
    wrap.innerHTML = `<div class="empty-state"><div class="empty-illustration">🗂️</div><p>No group projects yet. Create one below to track teammates and shared tasks.</p></div>`;
    return;
  }
  wrap.innerHTML = DB.projects.map((p) => {
    const course = p.courseId ? courseById(p.courseId) : null;
    const projectTasks = DB.tasks.filter((t) => t.projectId === p.id);
    const done = projectTasks.filter((t) => t.completed).length;
    const pct = projectTasks.length ? Math.round((done / projectTasks.length) * 100) : 0;
    return `<div class="project-card">
      <div class="project-head">
        <h4>${escapeHtml(p.name)} ${course ? `<span class="course-tag">${escapeHtml(course.name)}</span>` : ""}</h4>
        <button class="icon-btn tiny danger" onclick="deleteProject('${p.id}')">🗑</button>
      </div>
      <div class="bar-row"><div class="bar-track"><div class="bar-fill" style="width:${pct}%;background:#4C6FFF"></div></div><div class="bar-value">${done}/${projectTasks.length} (${pct}%)</div></div>

      <div class="teammates-row">
        ${p.teammates.map((m) => `<span class="pill">${escapeHtml(m.name)} <button class="pill-x" onclick="removeTeammate('${p.id}','${m.id}')">✕</button></span>`).join("")}
        <input type="text" id="teammateInput-${p.id}" placeholder="Add teammate" onkeydown="if(event.key==='Enter')addTeammate('${p.id}')">
        <button class="chip-btn" onclick="addTeammate('${p.id}')">Add</button>
      </div>

      <ul class="project-task-list">
        ${projectTasks.map((t) => `<li class="${t.completed ? "sub-done" : ""}">
          <label class="check-wrap small"><input type="checkbox" ${t.completed ? "checked" : ""} onchange="toggleTask('${t.id}')"><span class="checkmark"></span></label>
          <span>${escapeHtml(t.taskName)}</span>
          ${t.assignee ? `<span class="pill small">${escapeHtml(t.assignee)}</span>` : ""}
        </li>`).join("") || `<li class="hint">No sub-tasks yet.</li>`}
      </ul>
      <div class="project-add-task">
        <input type="text" id="ptaskInput-${p.id}" placeholder="New sub-task">
        <select id="ptaskAssignee-${p.id}">
          <option value="">Unassigned</option>
          ${p.teammates.map((m) => `<option value="${escapeHtml(m.name)}">${escapeHtml(m.name)}</option>`).join("")}
        </select>
        <button class="chip-btn" onclick="addProjectTask('${p.id}')">Add task</button>
      </div>
    </div>`;
  }).join("");
}

/* ---------------- dispatcher for the Courses & Projects tab ---------------- */
function renderCourses() {
  renderCourseList();
  renderProjects();
  if (window.renderQuizzes) renderQuizzes();
  if (window.renderGrades) renderGrades();
  refreshCourseDatalist();
}
