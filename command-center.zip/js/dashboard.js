/* =========================================================================
   dashboard.js — the command-center overview: totals, streak, average
   active day, insights, goal progress (a ring for today, a bar for the
   week), the 7-day chart, and the goals/pomodoro/notification settings.
   ========================================================================= */

function computeStreak(datesSet) {
  let streak = 0;
  let cursor = new Date();
  if (!datesSet.has(toDateStr(cursor.getTime()))) cursor.setDate(cursor.getDate() - 1);
  while (datesSet.has(toDateStr(cursor.getTime()))) {
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}
function computeAvgActiveDay(completed) {
  const byDate = {};
  completed.forEach((e) => { byDate[e.date] = (byDate[e.date] || 0) + e.duration; });
  const dates = Object.keys(byDate);
  if (!dates.length) return 0;
  return dates.reduce((s, d) => s + byDate[d], 0) / dates.length;
}

function saveGoalsForm() {
  DB.settings.dailyGoalMinutes = parseInt(document.getElementById("goalDaily").value) || 0;
  DB.settings.weeklyGoalMinutes = parseInt(document.getElementById("goalWeekly").value) || 0;
  DB.settings.reminderThresholdMinutes = parseInt(document.getElementById("goalReminder").value) || 90;
  DB.settings.pomodoroWorkMinutes = parseInt(document.getElementById("pomoWork").value) || 25;
  DB.settings.pomodoroBreakMinutes = parseInt(document.getElementById("pomoBreak").value) || 5;
  saveSettings();
  renderDashboard();
  toast("Settings saved.", { type: "success" });
}
async function enableNotifications() {
  if (!("Notification" in window)) { toast("Notifications aren't supported in this browser.", { type: "warning" }); return; }
  const perm = await Notification.requestPermission();
  DB.settings.notificationsEnabled = perm === "granted";
  saveSettings();
  toast(perm === "granted" ? "Due-date notifications enabled." : "Permission not granted.", { type: perm === "granted" ? "success" : "warning" });
  renderDashboard();
}

function renderDashboard() {
  document.getElementById("goalDaily").value = DB.settings.dailyGoalMinutes;
  document.getElementById("goalWeekly").value = DB.settings.weeklyGoalMinutes;
  document.getElementById("goalReminder").value = DB.settings.reminderThresholdMinutes;
  document.getElementById("pomoWork").value = DB.settings.pomodoroWorkMinutes;
  document.getElementById("pomoBreak").value = DB.settings.pomodoroBreakMinutes;
  document.getElementById("notifStatus").innerText = DB.settings.notificationsEnabled ? "✅ Enabled" : "Off";

  const dashDateInput = document.getElementById("dashDate");
  if (!dashDateInput.value) dashDateInput.value = toDateStr(Date.now());
  const selectedDate = dashDateInput.value;
  const completed = DB.timeEntries.filter((e) => e.end != null);

  const totalMs = completed.reduce((s, e) => s + e.duration, 0);
  document.getElementById("allTimeTotal").innerText = formatDuration(totalMs);
  document.getElementById("allTimeSessions").innerText = completed.length;
  const catTotals = {};
  completed.forEach((e) => { catTotals[e.category] = (catTotals[e.category] || 0) + e.duration; });
  const topCat = Object.entries(catTotals).sort((a, b) => b[1] - a[1])[0];
  document.getElementById("topCategory").innerText = topCat ? topCat[0] : "-";

  const datesSet = new Set(completed.map((e) => e.date));
  const streak = computeStreak(datesSet);
  document.getElementById("streakCard").innerText = streak;
  document.getElementById("avgPerDay").innerText = formatDuration(computeAvgActiveDay(completed));

  const days = [];
  for (let i = 6; i >= 0; i--) { const d = new Date(); d.setDate(d.getDate() - i); days.push(toDateStr(d.getTime())); }
  const dayTotalsArr = days.map((d) => completed.filter((e) => e.date === d).reduce((s, e) => s + e.duration, 0));
  const weekTotalMs = dayTotalsArr.reduce((s, v) => s + v, 0);
  const todayMs = completed.filter((e) => e.date === toDateStr(Date.now())).reduce((s, e) => s + e.duration, 0);

  // daily goal ring
  const dailyPct = DB.settings.dailyGoalMinutes > 0 ? Math.min(100, Math.round((todayMs / (DB.settings.dailyGoalMinutes * 60000)) * 100)) : 0;
  setRingProgress("dashRingFg", dailyPct);
  document.getElementById("dashRingLabel").innerHTML = DB.settings.dailyGoalMinutes > 0
    ? `<b>${dailyPct}%</b><span>of today's goal</span>` : `<b>${formatDuration(todayMs)}</b><span>today</span>`;

  // weekly goal bar
  const goalDiv = document.getElementById("weeklyGoalBar");
  if (DB.settings.weeklyGoalMinutes > 0) {
    const pct = Math.min(100, Math.round((weekTotalMs / (DB.settings.weeklyGoalMinutes * 60000)) * 100));
    goalDiv.innerHTML = `<div class="bar-row"><div class="bar-label">This week</div><div class="bar-track"><div class="bar-fill" style="width:${pct}%;background:#4C6FFF"></div></div><div class="bar-value">${formatDuration(weekTotalMs)} / ${DB.settings.weeklyGoalMinutes}m</div></div>`;
  } else {
    goalDiv.innerHTML = `<p class="hint">Set a weekly goal below to track progress here.</p>`;
  }

  // insights
  const insights = [];
  if (!completed.length) {
    insights.push("No sessions tracked yet — start a timer or log a past entry to see insights here.");
  } else {
    insights.push(streak > 0 ? `🔥 ${streak} day streak — keep it going.` : "Log time today to start a new streak.");
    const weekCatTotals = {};
    completed.filter((e) => days.includes(e.date)).forEach((e) => { weekCatTotals[e.category] = (weekCatTotals[e.category] || 0) + e.duration; });
    const weekTop = Object.entries(weekCatTotals).sort((a, b) => b[1] - a[1])[0];
    if (weekTop) insights.push(`📊 This week's biggest focus: <b>${escapeHtml(weekTop[0])}</b> (${formatDuration(weekTop[1])}).`);
    if (DB.settings.dailyGoalMinutes > 0) insights.push(`🎯 ${dailyPct}% of today's ${DB.settings.dailyGoalMinutes}-minute goal.`);
    insights.push(`⏱️ Average session: ${formatDuration(totalMs / completed.length)}.`);
    const dueSoon = DB.tasks.filter((t) => !t.completed && t.dueDate && daysUntil(t.dueDate) <= 2 && daysUntil(t.dueDate) >= 0).length;
    if (dueSoon > 0) insights.push(`⚠️ ${dueSoon} task${dueSoon === 1 ? "" : "s"} due in the next 2 days.`);
  }
  document.getElementById("insightsList").innerHTML = insights.map((i) => `<li>${i}</li>`).join("");

  // daily breakdown
  const dayEntries = completed.filter((e) => e.date === selectedDate);
  const dayTotal = dayEntries.reduce((s, e) => s + e.duration, 0);
  document.getElementById("dashDateTotal").innerText = dayEntries.length
    ? `Total tracked: ${formatDuration(dayTotal)} across ${dayEntries.length} session(s)` : "No time logged for this day yet.";
  const dayCatTotals = {};
  dayEntries.forEach((e) => { dayCatTotals[e.category] = (dayCatTotals[e.category] || 0) + e.duration; });
  const sorted = Object.entries(dayCatTotals).sort((a, b) => b[1] - a[1]);
  document.getElementById("dailyBreakdown").innerHTML = sorted.length
    ? sorted.map(([cat, ms]) => {
      const pct = dayTotal > 0 ? Math.round((ms / dayTotal) * 100) : 0;
      const meta = getCategoryMeta(cat);
      return `<div class="bar-row"><div class="bar-label">${meta.emoji} ${escapeHtml(cat)}</div><div class="bar-track"><div class="bar-fill" style="width:${pct}%;background:${meta.color}"></div></div><div class="bar-value">${formatDuration(ms)} (${pct}%)</div></div>`;
    }).join("")
    : `<p class="hint">Nothing logged for this day. <button class="chip-btn" onclick="showTab('tracker')">Go log something →</button></p>`;

  // 7-day chart
  const maxMs = Math.max(...dayTotalsArr, 1);
  document.getElementById("weekChart").innerHTML = days.map((d, i) => {
    const heightPct = Math.round((dayTotalsArr[i] / maxMs) * 100);
    const label = new Date(d + "T00:00:00").toLocaleDateString([], { weekday: "short" });
    return `<div class="week-col">
      <div class="week-val">${dayTotalsArr[i] > 0 ? formatDuration(dayTotalsArr[i]) : ""}</div>
      <div class="week-bar" style="height:${Math.max(heightPct, dayTotalsArr[i] > 0 ? 4 : 0)}%"></div>
      <div class="week-label">${label}<br>${d.slice(5)}</div>
    </div>`;
  }).join("");
}
