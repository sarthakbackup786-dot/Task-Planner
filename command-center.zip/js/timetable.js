/* =========================================================================
   timetable.js — weekly class schedule. CSV (PapaParse), Excel (SheetJS)
   and photo OCR (Tesseract.js) all funnel into the SAME editable review
   table before anything is saved, because none of the three parsers can
   be trusted blindly — OCR especially. Manual entry/edit is always
   available as the ground-truth fallback.
   ========================================================================= */

const DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
let pendingImportRows = [];
let editingSlotId = null;

/* ---------------- normalizing parsed rows ---------------- */
function normalizeRow(obj) {
  const get = (keys) => {
    for (const k of keys) {
      for (const objKey in obj) {
        if (objKey.toLowerCase().trim().replace(/\s+/g, "") === k) return String(obj[objKey]).trim();
      }
    }
    return "";
  };
  return {
    day: capitalizeDay(get(["day"])),
    start: get(["start", "starttime"]),
    end: get(["end", "endtime"]),
    courseName: get(["course", "coursename", "subject"]),
    room: get(["room", "location", "venue"]),
  };
}
function capitalizeDay(raw) {
  if (!raw) return "";
  const map = { mon: "Monday", tue: "Tuesday", wed: "Wednesday", thu: "Thursday", fri: "Friday", sat: "Saturday", sun: "Sunday" };
  return map[raw.slice(0, 3).toLowerCase()] || raw;
}
function normalizeTimeGuess(raw) {
  if (!raw) return "";
  const m = raw.trim().toLowerCase().match(/(\d{1,2})[:.](\d{2})\s?(am|pm)?/);
  if (!m) return "";
  let h = parseInt(m[1], 10);
  const min = m[2], ap = m[3];
  if (ap === "pm" && h < 12) h += 12;
  if (ap === "am" && h === 12) h = 0;
  return pad(h) + ":" + min;
}

/* ---------------- OCR text heuristic ---------------- */
function parseOcrText(text) {
  const dayRegex = /\b(mon|tue|wed|thu|fri|sat|sun)[a-z]*\b/i;
  const timeRegex = /(\d{1,2}[:.]\d{2}\s?(am|pm)?)\s*(-|to|–|—)\s*(\d{1,2}[:.]\d{2}\s?(am|pm)?)/i;
  const lines = text.split(/\n/).map((l) => l.trim()).filter(Boolean);
  const rows = [];
  let lastDay = "";
  lines.forEach((line) => {
    const dayMatch = line.match(dayRegex);
    if (dayMatch) lastDay = capitalizeDay(dayMatch[0]);
    const timeMatch = line.match(timeRegex);
    if (timeMatch) {
      const start = normalizeTimeGuess(timeMatch[1]);
      const end = normalizeTimeGuess(timeMatch[4]);
      const rest = line.replace(timeMatch[0], "").replace(dayRegex, "").replace(/[|_]+/g, " ").trim();
      rows.push({ day: lastDay || "Monday", start, end, courseName: rest || "Unknown class", room: "" });
    }
  });
  return rows;
}

/* ---------------- import handlers ---------------- */
function handleTimetableCSV(event) {
  const file = event.target.files[0];
  if (!file) return;
  Papa.parse(file, {
    header: true, skipEmptyLines: true,
    complete: (res) => {
      pendingImportRows = res.data.map(normalizeRow).filter((r) => r.day || r.courseName);
      renderImportReview();
      event.target.value = "";
      if (!pendingImportRows.length) toast("Couldn't find any rows in that CSV.", { type: "warning" });
    },
  });
}
function handleTimetableXLSX(event) {
  const file = event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    const data = new Uint8Array(e.target.result);
    const wb = XLSX.read(data, { type: "array" });
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
    pendingImportRows = rows.map(normalizeRow).filter((r) => r.day || r.courseName);
    renderImportReview();
    event.target.value = "";
    if (!pendingImportRows.length) toast("Couldn't find any rows in that spreadsheet.", { type: "warning" });
  };
  reader.readAsArrayBuffer(file);
}
async function handleTimetableOCR(event) {
  const file = event.target.files[0];
  if (!file) return;
  const statusEl = document.getElementById("ocrStatus");
  statusEl.innerHTML = `<div class="skeleton skeleton-line"></div><div class="skeleton skeleton-line short"></div><p class="hint">Reading image… this can take up to a minute.</p>`;
  try {
    const result = await Tesseract.recognize(file, "eng");
    const rows = parseOcrText(result.data.text);
    pendingImportRows = rows;
    renderImportReview();
    statusEl.innerHTML = rows.length
      ? `<p class="hint">Found ${rows.length} possible slot(s) below — OCR is never perfect, please check each row.</p>`
      : `<p class="hint">Couldn't confidently detect any slots in that image. Try a clearer photo, or use manual entry below.</p>`;
  } catch (err) {
    statusEl.innerHTML = `<p class="hint">OCR failed (${escapeHtml(err.message || "unknown error")}). Try manual entry instead.</p>`;
  }
  event.target.value = "";
}

/* ---------------- review table (shared by all three import paths) ---------------- */
function renderImportReview() {
  const wrap = document.getElementById("importReviewWrap");
  if (!pendingImportRows.length) { wrap.innerHTML = ""; wrap.classList.remove("show"); return; }
  wrap.classList.add("show");
  wrap.innerHTML = `
    <h4>Review before importing (${pendingImportRows.length} row${pendingImportRows.length === 1 ? "" : "s"})</h4>
    <p class="hint">Fix anything that looks wrong, then confirm.</p>
    <div class="table-scroll"><table class="review-table"><thead><tr><th>Day</th><th>Start</th><th>End</th><th>Course</th><th>Room</th><th></th></tr></thead>
    <tbody>${pendingImportRows.map((r, i) => reviewRowHtml(r, i)).join("")}</tbody></table></div>
    <button class="chip-btn" onclick="addBlankReviewRow()">+ Add row</button>
    <div class="edit-actions">
      <button class="btn add-btn" onclick="confirmImportRows()">Confirm Import</button>
      <button class="btn ghost-btn" onclick="discardImportRows()">Discard</button>
    </div>`;
}
function reviewRowHtml(r, i) {
  return `<tr>
    <td><select onchange="updateReviewRow(${i},'day',this.value)">${DAY_NAMES.map((d) => `<option value="${d}" ${r.day === d ? "selected" : ""}>${d}</option>`).join("")}</select></td>
    <td><input type="time" value="${r.start || ""}" onchange="updateReviewRow(${i},'start',this.value)"></td>
    <td><input type="time" value="${r.end || ""}" onchange="updateReviewRow(${i},'end',this.value)"></td>
    <td><input type="text" value="${escapeHtml(r.courseName || "")}" onchange="updateReviewRow(${i},'courseName',this.value)"></td>
    <td><input type="text" value="${escapeHtml(r.room || "")}" onchange="updateReviewRow(${i},'room',this.value)"></td>
    <td><button class="icon-btn tiny danger" onclick="removeReviewRow(${i})">✕</button></td>
  </tr>`;
}
function updateReviewRow(i, field, val) { pendingImportRows[i][field] = val; }
function removeReviewRow(i) { pendingImportRows.splice(i, 1); renderImportReview(); }
function addBlankReviewRow() { pendingImportRows.push({ day: "Monday", start: "", end: "", courseName: "", room: "" }); renderImportReview(); }
function discardImportRows() { pendingImportRows = []; renderImportReview(); }
function confirmImportRows() {
  let added = 0;
  pendingImportRows.forEach((r) => {
    if (!r.day || !r.start || !r.courseName) return;
    const course = getOrCreateCourse(r.courseName);
    DB.timetable.push({ id: uid("tt"), day: r.day, start: r.start, end: r.end || r.start, courseId: course.id, room: r.room || "" });
    added++;
  });
  saveTimetable();
  pendingImportRows = [];
  renderImportReview();
  renderTimetable();
  if (window.refreshCourseDatalist) refreshCourseDatalist();
  toast(`Imported ${added} class slot(s).`, { type: "success" });
}

/* ---------------- manual add/edit/delete ---------------- */
function addManualSlot() {
  const day = document.getElementById("ttDay").value;
  const start = document.getElementById("ttStart").value;
  const end = document.getElementById("ttEnd").value;
  const courseName = document.getElementById("ttCourse").value.trim();
  const room = document.getElementById("ttRoom").value.trim();
  if (!day || !start || !courseName) { toast("Day, start time and course are required.", { type: "warning" }); return; }
  const course = getOrCreateCourse(courseName);
  DB.timetable.push({ id: uid("tt"), day, start, end: end || start, courseId: course.id, room });
  saveTimetable();
  document.getElementById("ttCourse").value = "";
  document.getElementById("ttRoom").value = "";
  renderTimetable();
  if (window.refreshCourseDatalist) refreshCourseDatalist();
  toast("Class added to timetable.", { type: "success" });
}
async function deleteSlot(id) {
  const ok = await confirmModal({ title: "Remove this class?", message: "This can't be undone.", confirmLabel: "Remove" });
  if (!ok) return;
  DB.timetable = DB.timetable.filter((s) => s.id !== id);
  saveTimetable(); renderTimetable();
  toast("Removed from timetable.", { type: "danger" });
}
function startEditSlot(id) { editingSlotId = id; renderTimetable(); }
function cancelEditSlot() { editingSlotId = null; renderTimetable(); }
function saveEditSlot(id) {
  const slot = DB.timetable.find((s) => s.id === id);
  slot.day = document.getElementById("esday-" + id).value;
  slot.start = document.getElementById("esstart-" + id).value;
  slot.end = document.getElementById("esend-" + id).value;
  slot.courseId = getOrCreateCourse(document.getElementById("escourse-" + id).value.trim()).id;
  slot.room = document.getElementById("esroom-" + id).value.trim();
  saveTimetable(); editingSlotId = null; renderTimetable();
  toast("Class updated.", { type: "success" });
}

/* ---------------- render weekly grid (stacks to a list on mobile via CSS) ---------------- */
function renderTimetable() {
  const wrap = document.getElementById("timetableGrid");
  if (DB.timetable.length === 0) {
    wrap.innerHTML = `<div class="empty-state">
      <div class="empty-illustration">🗓️</div>
      <p>No timetable yet. Import a CSV/Excel file, upload a photo of your schedule, or add classes manually below.</p>
    </div>`;
    return;
  }
  wrap.innerHTML = DAY_NAMES.map((day) => {
    const slots = DB.timetable.filter((s) => s.day === day).sort((a, b) => a.start.localeCompare(b.start));
    return `<div class="day-col">
      <h4>${day}</h4>
      <div class="day-slots">${slots.length ? slots.map(slotCardHtml).join("") : `<p class="hint">No classes</p>`}</div>
    </div>`;
  }).join("");
}
function slotCardHtml(s) {
  const course = courseById(s.courseId);
  const color = course ? course.color : "#6B7280";
  if (editingSlotId === s.id) {
    return `<div class="slot-card editing" style="border-left-color:${color}">
      <select id="esday-${s.id}">${DAY_NAMES.map((d) => `<option value="${d}" ${s.day === d ? "selected" : ""}>${d}</option>`).join("")}</select>
      <input type="time" id="esstart-${s.id}" value="${s.start}">
      <input type="time" id="esend-${s.id}" value="${s.end}">
      <input type="text" id="escourse-${s.id}" value="${escapeHtml(course ? course.name : "")}" list="courseDatalist">
      <input type="text" id="esroom-${s.id}" value="${escapeHtml(s.room || "")}" placeholder="Room">
      <div class="edit-actions">
        <button class="btn save-btn tiny" onclick="saveEditSlot('${s.id}')">Save</button>
        <button class="btn ghost-btn tiny" onclick="cancelEditSlot()">Cancel</button>
      </div>
    </div>`;
  }
  return `<div class="slot-card" style="border-left-color:${color}">
    <div class="slot-time">${s.start}${s.end && s.end !== s.start ? "–" + s.end : ""}</div>
    <div class="slot-course">${course ? escapeHtml(course.name) : "Unknown course"}</div>
    ${s.room ? `<div class="slot-room">📍 ${escapeHtml(s.room)}</div>` : ""}
    <div class="slot-actions">
      <button class="icon-btn tiny" onclick="startEditSlot('${s.id}')">✎</button>
      <button class="icon-btn tiny danger" onclick="deleteSlot('${s.id}')">✕</button>
    </div>
  </div>`;
}
